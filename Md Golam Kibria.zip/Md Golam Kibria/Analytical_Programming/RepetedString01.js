let str = "aba";
let n=10;
let len=str.length;
let en="";
if(n>len){
  let mul=Math.ceil(n/len)
  for(let i=0;i<mul;i++){
    en=en+str;
  }
}
let splited=en.slice(0,n); 
let count = (splited.match(/\a/g) || []).length;
console.log(count);

// Its time complexity is linear O(n) in worst case str can be a single char