let s="eello";
let spliced=s.split('').splice(1,s.length-2).join('');
let numberOfVowel=spliced.match(/[aeiou]/ig).length;
console.log(numberOfVowel);



///Some analytics 
//Its time complexity is order of n O(n) becuse array splice method take O(n) time in worst case
